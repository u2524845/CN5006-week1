const num1=8;
const num2=2;

const sum=num1+num2;
const sub=num1-num2;
const mult=num1*num2;
const div=num1/num2;

console.log("The sum is: "+sum);
console.log("The substration is: "+sub);
console.log("The multiplication is: "+mult);
console.log("The division is: "+div);
